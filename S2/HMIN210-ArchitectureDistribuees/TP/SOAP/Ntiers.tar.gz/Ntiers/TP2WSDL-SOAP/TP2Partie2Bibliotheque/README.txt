Il contient 3 projets:

	1- TP2BiblioService est le Web Service qui assure les fonctionalités de la Bibliotheque. Il contient les classes Book et Comment, 3 classes pour les Utilisateurs, la classe statique Library, et le Web Service.

	2- TP2BiblioAdmin est un programme Client utilisé par les administrateurs de la bibliotheque. Il contient le programme principale, ainsi qu'une classe Helper contenant quelques fonctions d'affichage.

	3- TP2BiblioClient est un programme Client utilisé par les utilisateurs reguliers de la bibliotheque (les subscribers). Il contient le programme principale, ainsi qu'une classe Helper contenant quelques fonctions d'affichage.

Des instructions sont mises dans le programme pour permettre de le tester facilement. Ces instructions apparaissent lors de l'éxecution du programme.
