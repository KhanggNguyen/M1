﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

/// <summary>
/// Summary description for Book
/// </summary>
/// 
[Serializable]
public class Book
{

    public int isbn { get; set; }
    public string title { get; set; }
    public string author { get; set; }
    public string editor { get; set; }
    public int numberOfCopies { get; set; } //numero d'exemplaires
    public List<Comment> commentList { get; set; }

    public Book()
    {

    }

    public Book(int isbn, string title, string author, string editor, int numberOfCopies)
    {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.editor = editor;
        this.numberOfCopies = numberOfCopies;
        commentList = new List<Comment>();
    }

    public override string ToString()
    {
        string book = "isbn: " + isbn + Environment.NewLine + "title: " + title + Environment.NewLine + "author: " + author + Environment.NewLine + "editor" + editor + Environment.NewLine + "number of copies: " + numberOfCopies + Environment.NewLine;
        StringBuilder builder = new StringBuilder();
        builder.Append(book);

        for (int i = 0; i < commentList.Count; i++)
            builder.Append(commentList[i].ToString());

        return builder.ToString() ;
     }
}