﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Subscriber represents the regular user interacting with the system
/// </summary>
/// 

[Serializable]
public class Subscriber : User
{
    public int age { get; set; }

    public Subscriber() : base()
    {
    }

    public Subscriber(int id, string password,  int age) : base(id, password)
    {
        this.age = age;
    }

    
}