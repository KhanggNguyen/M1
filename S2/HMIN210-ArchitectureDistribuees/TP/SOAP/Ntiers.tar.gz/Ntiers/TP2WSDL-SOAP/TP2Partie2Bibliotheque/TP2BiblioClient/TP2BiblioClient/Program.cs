using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TP2BiblioClient.ServiceReference1;

namespace TP2BiblioClient
{
    class Program
    {

        private static WebServiceSoapClient proxy;
        public static int? userid { get; set; }

        static void Main(string[] args)
        {
            Console.WriteLine("To test this Client program, you have to login as a Subscriber.\nSome Books, Comments, Admins and Subscribers are already added for you to test this app.\n You can use the following id and password to login as a subscriber. \nID: 1 \nPassword: pass\nPress enter to continue.");
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("Hello. This is the Library's subsriber app. Please log in or sign up to proceed.");
            proxy = new WebServiceSoapClient();

            int choice1 = 0;
            while (choice1 < 1 || choice1 > 2 )
            {
                Console.WriteLine("1: Sign in. 2: Sign up");
                if (int.TryParse(Console.ReadLine(), out choice1))
                {
                    switch (choice1)
                    {
                        case 1:

                            break;
                        case 2:
                            Console.WriteLine("Enter your desired password: ");
                            string passwordinput = Console.ReadLine();
                            Console.WriteLine("Enter your age: ");
                            int ageinput;
                            if (int.TryParse(Console.ReadLine(), out ageinput))
                            {
                                int? signupres = signup(passwordinput, ageinput);
                                if(signupres == null)
                                {
                                    Console.WriteLine("Cannot sign you up");
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("Congrats you are signed up. Youd ID is:  " + signupres.Value);
                                }
                            }
                            else
                            {
                                Console.WriteLine("Age not valid");
                            }
                                
                            break;
                        default:

                            break;

                    }

                }

            }
            //log in loop
            while (userid == null)
            {
                Console.WriteLine("\n\nPlease login to use this application");
                Console.WriteLine("User id: ");
                int useridinput;
                if (int.TryParse(Console.ReadLine(), out useridinput))
                {
                    //valid input
                    Console.WriteLine("Password: ");
                    string passinput = Console.ReadLine();

                    if (loginSubscriber(useridinput, passinput))
                        Console.WriteLine("logged in");
                    else
                        Console.WriteLine("log in failed");
                }
                else
                {
                    //invalid input
                    Console.WriteLine("The user id is a number, no letters can be included");
                }
            }
            //end of the login loop

            while (true)
            {
                displayMenu();
                int option;
                if (int.TryParse(Console.ReadLine(), out option))
                {
                    //valid input
                    //valid option
                    switch (option)
                    {
                        case 0:
                            Console.WriteLine("exiting...");
                            userid = null;
                            Environment.Exit(0);
                            break;

                        case 1:
                            Console.WriteLine("Enter the ISBN you want to search for: ");
                            Console.WriteLine("you can use the ISBN 1 to test.");
                            int isbninput;
                            if (int.TryParse(Console.ReadLine(), out isbninput))
                            {
                                Book bookres = searchByISBN(isbninput);
                                if(bookres == null)
                                {
                                    Console.WriteLine("The book you wanted isn't in our catalogue");
                                    Console.WriteLine("\n\n.....Press any key to continue.....");
                                    break;
                                }
                                Console.WriteLine(Helper.printBook(bookres));
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                            }
                            else
                            {
                                Console.WriteLine("Invalid input");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }

                            break;
                        case 2:
                            Console.WriteLine("Enter the author you want to search for: ");
                            Console.WriteLine("(You can use the author \"JK Rowling\" to test)\n");
                            string authorname = Console.ReadLine();
                            Book[] reslist = searchByAuthor(authorname);
                            if (reslist.Length == 0)
                            {
                                Console.WriteLine("No results found for this author");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }
                            else
                            {
                                Console.WriteLine("We found " + reslist.Length + " results: \n");
                                for (int i = 0; i < reslist.Length; i++)
                                {
                                    Console.WriteLine(Helper.printBook(reslist[i]));
                                }


                            }
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;

                        case 3:
                            Console.WriteLine("Enter the ISBN of the book you want to comment");
                            int isbncommentinput;
                            if (int.TryParse(Console.ReadLine(), out isbncommentinput))
                            {
                                Console.WriteLine("Enter your comment");
                                string commentinput = Console.ReadLine();
                                bool commentres = addComment(isbncommentinput, commentinput);
                                if (commentres)
                                    Console.WriteLine("Your comment was added");
                                else
                                    Console.WriteLine("The book you tried to comment doesn't exist in our catalogue");
                            }
                            else
                            {
                                Console.WriteLine("Invalid input");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }
                            break;
                        case 4:
                            Book[] allbooks = getAllBooks();
                            if (allbooks.Length == 0)
                            {
                                Console.WriteLine("No results found for this author");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Our catalogue contains " + allbooks.Length + " books\n");
                                for (int i = 0; i < allbooks.Length; i++)
                                {
                                    Console.WriteLine(Helper.printBookShort(allbooks[i]));
                                }


                            }
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;
                        default:
                            Console.Write("Invalid option");
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;

                    }

                }

                Console.ReadKey();
            }
        }

        public static Book[] getAllBooks()
        {
            return proxy.getAllBooks();
        }
        public static Book searchByISBN(int isbn)
        {
            return proxy.SearchByISBN(isbn);
        }

        public static Book[] searchByAuthor(string author)
        {
            return proxy.SearchByAuthor(author);
        }

        public static bool loginSubscriber(int id, string password)
        {
            bool res = proxy.loginSubscriber(id, password);
            Console.WriteLine(res);
            if (res)
            {
                userid = id;
                Console.WriteLine("Welcome user #" + userid);
                return true;
            }
            return false;
        }

        public static void logout(int id)
        {
            userid = null;
            proxy.logout(id);
        }

        public static bool addComment(int isbn, string comment)
        {
            return proxy.addComment(isbn, userid.Value, comment);
        }

        public static void displayMenu()
        {
            Console.Clear();
            Console.WriteLine("Menu");
            Console.WriteLine("Choose an option by writing its number:");
            Console.WriteLine("0- exit");
            Console.WriteLine("1- Search by ISBN");
            Console.WriteLine("2- Search by Author's name");
            Console.WriteLine("3- Add comment");
            Console.WriteLine("4- Get all books");
        }

        public static int? signup(string pass, int age)
        {
            return proxy.addSubscriber(pass, age);
        }
    }
}