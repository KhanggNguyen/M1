﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Administrators are the librarians
/// </summary>
/// 

[Serializable]
public class Admin : User
{
    public string library_name { get; set; }

    public Admin() : base()
    {

    }

    public Admin(int id, string password, string library_name) : base(id, password)
    {
        this.library_name = library_name;
    }
}