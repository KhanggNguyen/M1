﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Abstract class to represent different kinds of users of this application (subscribers and admins)
/// </summary>
/// 

[Serializable]
public abstract class User
{
    public int? id { get; set; }
    public string password { get; set; }
    public User()
    {

    }

    protected User(int id, string password)
    {
        this.id = id;
        this.password = password;
    }

    public override string ToString()
    {
        return base.ToString();
    }
}