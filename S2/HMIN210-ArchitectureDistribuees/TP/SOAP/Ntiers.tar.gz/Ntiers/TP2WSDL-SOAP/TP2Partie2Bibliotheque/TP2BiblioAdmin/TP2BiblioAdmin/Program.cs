using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TP2BiblioAdmin.ServiceReference1;

namespace TP2BiblioAdmin
{
    class Program
    {
        private static WebServiceSoapClient proxy;
        public static int? userid { get; set; }

        static void Main(string[] args)
        {

            Console.WriteLine("To test this Client program, you have to login as an Admin.\nSome Books, Comments, Admins and Subscribers are already added for you to test this app.\n You can use the following id and password to login as a Admin. \nID: 3 \nPassword: pass\nPress enter to continue.");
            Console.ReadKey();
            Console.Clear();

            proxy = new WebServiceSoapClient();
            Console.WriteLine("Hello. This is the Library's administrator app. Please log in to proceed.");

            //log in loop
            while (userid == null)
            {
                Console.WriteLine("\n\nPlease login to use this application");
                Console.WriteLine("User id: ");
                int useridinput;
                if (int.TryParse(Console.ReadLine(), out useridinput))
                {
                    //valid input
                    Console.WriteLine("Password: ");
                    string passinput = Console.ReadLine();

                    if (loginAdmin(useridinput, passinput))
                        Console.WriteLine("logged in");
                    else
                        Console.WriteLine("log in failed");
                }
                else
                {
                    //invalid input
                    Console.WriteLine("The user id is a number, no letters can be included");
                }
            }
            //end of the login loop

            while (true)
            {
                displayMenu();
                int option;
                if (int.TryParse(Console.ReadLine(), out option))
                {
                    //valid input
                    //valid option
                    switch (option)
                    {
                        case 0:
                            Console.WriteLine("exiting...");
                            userid = null;
                            Environment.Exit(0);
                            break;
                        case 1:
                            Console.WriteLine("Enter the ISBN you want to search for: ");
                            Console.WriteLine("you can use the ISBN 1 to test.");
                            int isbninput;
                            if (int.TryParse(Console.ReadLine(), out isbninput))
                            {
                                Book bookres = searchByISBN(isbninput);
                                if (bookres == null)
                                {
                                    Console.WriteLine("The book you are searching for isn't in our catalogue");
                                    Console.WriteLine(".....Press any key to continue.....");
                                    break;
                                }
                                Console.WriteLine(Helper.printBook(bookres));
                            }
                            else
                            {
                                Console.WriteLine("Invalid input");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;
                        case 2:
                            Console.WriteLine("Enter the author you want to search for: ");
                            Console.WriteLine("(You can use the author \"JK Rowling\" to test)\n");
                            string authorname = Console.ReadLine();

                            Book[] reslist = searchByAuthor(authorname);
                            if (reslist.Length == 0)
                            {
                                Console.WriteLine("No results found for this author");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }
                            else
                            {
                                Console.WriteLine("We found " + reslist.Length + " results");
                                for (int i = 0; i < reslist.Length; i++)
                                {
                                    Console.WriteLine(Helper.printBook(reslist[i]));
                                }


                            }
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;

                        case 3:
                            Console.WriteLine("Enter the following fields to add a book: ");
                            Console.WriteLine("ISBN: ");
                            int isbnbookinput;
                            if (!int.TryParse(Console.ReadLine(), out isbnbookinput))
                            {
                                Console.WriteLine("Invalid ISBN.");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }

                            Console.WriteLine("Title: ");
                            string titleinput = Console.ReadLine();

                            Console.WriteLine("Author: ");
                            string authorinput = Console.ReadLine();

                            Console.WriteLine("Editor: ");
                            string editorinput = Console.ReadLine();

                            Console.WriteLine("Number of copies: ");
                            int copiesbookinput;
                            if (!int.TryParse(Console.ReadLine(), out copiesbookinput))
                            {
                                Console.WriteLine("Invalid number of copies.");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }
                            if (copiesbookinput < 0)
                            {
                                Console.WriteLine("Invalid number of copies.");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }

                            Console.WriteLine("Your book is getting added.");
                            bool resAddBook = addBook(isbnbookinput, titleinput, authorinput, editorinput, copiesbookinput);
                            if (resAddBook)
                                Console.WriteLine("Book successfully added.");
                            else
                                Console.WriteLine("The book you wanted to add could not be added");
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;

                        case 4:
                            Console.WriteLine("Enter the ISBN of the book you want to remove: ");
                            int isbnremoveinput;
                            if (int.TryParse(Console.ReadLine(), out isbnremoveinput))
                            {
                                bool removeres = removeBook(isbnremoveinput);
                                if (removeres)
                                    Console.WriteLine("Book succesfully removed");
                                else
                                    Console.Write("The book you tried to remove isn't in the catalogue");

                            }
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;
                        case 5:
                            Console.WriteLine("Add a subscriber to the library system.");
                            Console.WriteLine("Enter the desired password for the subscriber: ");
                            string passwordinput = Console.ReadLine();
                            Console.WriteLine("Enter the subscriber's  age: ");
                            int ageinput;
                            if (int.TryParse(Console.ReadLine(), out ageinput))
                            {
                                int? signupres = signup(passwordinput, ageinput);
                                if (signupres == null)
                                {
                                    Console.WriteLine("Error signing up the subscriber");
                                    Console.WriteLine("\n\n.....Press any key to continue.....");
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("Congrats the subscriber has been added. Their ID is:  " + signupres.Value);
                                }
                            }
                            else
                            {
                                Console.WriteLine("Age not valid");
                            }
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;
                        case 6:
                            Book[] allbooks = getAllBooks();
                            if (allbooks.Length == 0)
                            {
                                Console.WriteLine("No results found for this author");
                                Console.WriteLine("\n\n.....Press any key to continue.....");
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Our catalogue contains " + allbooks.Length + " books\n");
                                for (int i = 0; i < allbooks.Length; i++)
                                {
                                    Console.WriteLine(Helper.printBookShort(allbooks[i]));
                                }


                            }
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;
                        default:
                            Console.Write("Invalid option");
                            Console.WriteLine("\n\n.....Press any key to continue.....");
                            break;
                    }
                    Console.ReadKey();
                }
            }
        }

        public static Book[] getAllBooks()
        {
            return proxy.getAllBooks();
        }
        public static Book searchByISBN(int isbn)
        {
            return proxy.SearchByISBN(isbn);
        }

        public static Book[] searchByAuthor(string author)
        {
            return proxy.SearchByAuthor(author);
        }
        public static bool loginAdmin(int id, string password)
        {
            bool res = proxy.loginAdmin(id, password);
            if (res)
            {
                userid = id;
                Console.WriteLine("Welcome user #" + userid);
                return true;
            }
            return false;
        }

        public static void logout(int id)
        {
            userid = null;
            proxy.logout(id);
        }

        public static bool addBook(int isbn, string title, string author, string editor, int nb)
        {
            return proxy.addBook(isbn, title, author, editor, nb);
        }

        public static bool removeBook(int isbn)
        {
            return proxy.removeBook(isbn);
        }

        public static void displayMenu()
        {
            Console.Clear();
            Console.WriteLine("Menu");
            Console.WriteLine("Choose an option by writing its number:");
            Console.WriteLine("0- exit");
            Console.WriteLine("1- Search by ISBN");
            Console.WriteLine("2- Search by Author's name");
            Console.WriteLine("3- Add book");
            Console.WriteLine("4- Remove book");
            Console.WriteLine("5- Add a subscriber");
            Console.WriteLine("6- List all books");
        }

        public static int? signup(string pass, int age)
        {
            return proxy.addSubscriber(pass, age);
        }
    }
}
