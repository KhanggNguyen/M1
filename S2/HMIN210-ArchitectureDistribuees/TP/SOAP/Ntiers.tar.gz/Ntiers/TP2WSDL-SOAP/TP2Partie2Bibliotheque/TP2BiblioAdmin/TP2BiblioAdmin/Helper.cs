﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TP2BiblioAdmin.ServiceReference1;

namespace TP2BiblioAdmin
{
    class Helper
    {
        //function to format the Book string
        public static string printBook(Book b)
        {
            if(b == null)
            {
                return "The book you're asking for doesn't exist";
            }
            string book = "isbn: " + b.isbn + Environment.NewLine + "title: " + b.title + Environment.NewLine + "author: " + b.author + Environment.NewLine + "editor" + b.editor + Environment.NewLine + "number of copies: " + b.numberOfCopies + Environment.NewLine;
            StringBuilder builder = new StringBuilder();
            builder.Append(book);

            for (int i = 0; i < b.commentList.Count(); i++)
                builder.Append(printComment(b.commentList[i]));
            builder.Append("=======================================================");
            return builder.ToString();
        }

        //function to print books without all their data
        public static string printBookShort(Book b)
        {
            string book = "isbn: " + b.isbn + Environment.NewLine + "title: " + b.title + Environment.NewLine + "author: " + b.author + "\n==================================";
            return book;
        }
        //function to format the Comment string
        public static string printComment(Comment c)
        {
            return "userid: " + c.userId + Environment.NewLine + "comment: " + c.text;
        }
    }
}
