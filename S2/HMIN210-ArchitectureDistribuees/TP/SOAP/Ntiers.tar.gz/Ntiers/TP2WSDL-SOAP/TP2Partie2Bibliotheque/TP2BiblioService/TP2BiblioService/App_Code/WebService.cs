﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService
{
    public Book b;
    public List<Comment> comments;

    public WebService()
    {

    }

    [WebMethod]
    public List<Book> getAllBooks()
    {
        return Library.getAllBooks();
    }

    [WebMethod]
    public string getAllSubscribers()
    {
        List<Subscriber> list = Library.getAllSubscribers();
        string str = "";
        foreach(Subscriber s in list)
        {
            str = str + s.ToString();

        }
        return list.Count.ToString();
    }

    [WebMethod]
    public string getAllAdmins()
    {
        List<Admin> list = Library.getAllAdmins();
        string str = "";
        foreach (Admin a in list)
        {
            str = str + a.id + " : " + a.password;

        }
        return str;
    }


    [WebMethod]
    public string HelloWorld()
    {
        return "Hello World";
    }

    [WebMethod]
    public string TestBook()
    {
        return Library.catalogue[0].ToString();
    }

    [WebMethod]
    public Book TestBookObjectList()
    {
        return Library.catalogue[0];
    }

    [WebMethod]
    public Book TestBookObject()
    {
        return this.b;
    }

    [WebMethod]
    public Book SearchByISBN(int isbn)
    {
        return Library.searchByISBN(isbn);
    }

    [WebMethod]
    public List<Book> SearchByAuthor(string author)
    {
        return Library.searchByAuthor(author);
    }

    [WebMethod]
    public bool loginSubscriber(int id, string password)
    {
        return Library.loginSubscriber(id, password);
    }

    [WebMethod]
    public bool loginAdmin(int id, string password)
    {
        return Library.loginAdmin(id, password);
    }

    [WebMethod]
    public void logout(int id)
    {
        Library.logout(id);
    }

    [WebMethod]
    public bool addComment(int isbn, int userid, string comment)
    {
        return Library.addComment(isbn, userid, comment);
    }

    [WebMethod]
    public bool addBook(int isbn, string title, string author, string editor, int nb)
    {
        return Library.addBook(isbn, title, author, editor, nb);
    }

    [WebMethod]
    public bool removeBook(int isbn)
    {
        return Library.removeBook(isbn);
    }

   
    [WebMethod]
    public int? addSubscriber(string password, int age)
    {
        Subscriber res = Library.addSubscriber(password, age);
        if (res == null)
            return 0;
        return res.id;

    }



}