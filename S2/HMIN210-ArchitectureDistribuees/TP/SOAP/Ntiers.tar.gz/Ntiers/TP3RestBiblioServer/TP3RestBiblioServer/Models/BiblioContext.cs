﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MySql.Data.EntityFrameworkCore;

namespace TP3RestBiblioServer.Models
{
    public class BiblioContext : DbContext
    {
        //properties
        public DbSet<Book> Books { get; set; }
        public DbSet<Exemplaire> Exemplaires { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Subscriber> Subscribers { get; set; }

        //contructor
        public BiblioContext(DbContextOptions<BiblioContext> options) : base(options)
        {
            //add book 1 to test

            /*
            Book b1 = new Book(1, "Learn C", "Linus", "editor", 5);
            Comment c1 = new Comment(1, 1, "good book", b1, 1);
            Comment c2 = new Comment(2, 3, "Helpful book", b1, 1);
            b1.CommentList.Add(c1);
            b1.CommentList.Add(c2);

            this.Books.AddAsync(b1);
            this.SaveChangesAsync();
            */

        }

        /*
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL("server=localhost;port=3306;database=library;user=root;password=");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Comment>(entity =>
            {
                entity.HasKey(c => c.Id);
                entity.Property(e => e.text).IsRequired();
                entity.Property(e => e.userId);
            });
        }

    */

    }
}
