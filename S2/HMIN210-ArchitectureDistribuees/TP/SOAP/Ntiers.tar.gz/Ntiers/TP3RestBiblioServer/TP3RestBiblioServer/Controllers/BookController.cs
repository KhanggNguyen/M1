﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TP3RestBiblioServer.Models;

namespace TP3RestBiblioServer.Controllers
{
    

    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly BiblioContext _context;

        //constructor
        public BookController(BiblioContext context)
        {
            _context = context;
            if (_context.Books.Count() == 0)
            {
                //add book 1 to test

                
                Book b1 = new Book(1, "Learn C", "Linus", "editor", 5);
                Comment c1 = new Comment(1, 1, "good book", 1);
                Comment c2 = new Comment(2, 3, "Helpful book", 1);
                b1.CommentList.Add(c1);
                b1.CommentList.Add(c2);

                _context.Books.AddAsync(b1);
                

                /*
                //add book 2 to test
                List<Comment> b2comments = new List<Comment>();
                b2comments.Add(new Comment(3, 1, "very well written"));
                b2comments.Add(new Comment(4, 2, "the exercises could be better"));
                List<Exemplaire> b2exemplaires = new List<Exemplaire>();
                Book b2 = new Book(2, "Learn Java", "Oracle", "editor", 209, b2comments, b2exemplaires);


                //add book 3 to test
                List<Comment> b3comments = new List<Comment>();
                b3comments.Add(new Comment(5, 1, "good book"));
                b3comments.Add(new Comment(6, 2, "Helpful book"));

                List<Exemplaire> b3exemplaires = new List<Exemplaire>();

                Book b3 = new Book(3, "Learn linux", "Linus", "editor", 2, b3comments, b3exemplaires);
                //add books to context
                _context.AddAsync(b1);
                _context.AddAsync(b2);
                _context.AddAsync(b3);
                */

                //persist the changes
                _context.SaveChangesAsync();
            }
        }

        //getting all books
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Book>>> GetBooksTest()
        {
            var list = await _context.Books.ToListAsync();

            if(list.Count() == 0)
            {
                return NotFound();
            }
            else
            {
                for(int i = 0; i < list.Count(); i++)
                {
                    list[i].CommentList = await _context.Comments.Where(c => c.BookId == list[i].Id).ToListAsync();
                }
                return list;
            }
            
        }

        //search book by ISBN
        [HttpGet("isbn/{isbn}")]
        public async Task<ActionResult<Book>> SearchByISBN(int isbn)
        {
            var bookres = await _context.Books.FindAsync(isbn);
            if (bookres == null)
                return NotFound();
            else
            {
                bookres.CommentList = await _context.Comments.Where(c => c.BookId == isbn).ToListAsync();
                return bookres;
            }
            
        }

        //search by author name
        [HttpGet("author/{author}")]
        public async Task<ActionResult<IEnumerable<Book>>> SearchByAuthor(String author)
        {
            
            List<Book> bookres = await _context.Books.Where(x => author.Contains(x.Author)).ToListAsync();
            if (bookres == null)
                return NotFound();
            return bookres;
            
            /*
             * 2eme methode
            var books = (from b in _context.Books
                         where author.Any(a => b.Author.Contains(a))
                         select b).ToList();
            return books;
            */
        }

        //test getting all comments in the DB
        [HttpGet("comments")]
        public async Task<ActionResult<IEnumerable<Comment>>> GetAllComments()
        {
            return await _context.Comments.ToListAsync();
        }

        //get comments of one book
        
        [HttpGet("isbn/{id}/comments")]
        public async Task<ActionResult<IEnumerable<Comment>>> GetBooksComments(int id)
        {
            return  await _context.Comments.Where(c => c.BookId == id).ToListAsync();
        }
        
        //get a comment by its ID
        [HttpGet("comments/{cid}")]
        public async Task<ActionResult<Comment>> GetCommentById(int cid)
        {
            return await _context.Comments.FindAsync(cid);
        }

        //get a comment of a book by ID
        [HttpGet("isbn/{id}/comments/{cid}")]
        public async Task<ActionResult<IEnumerable<Comment>>> GetBookCommentById(int id, int cid)
        {
            return await _context.Comments.Where(c => c.BookId == id && c.Id == cid).ToListAsync();
        }
        //Edit a book
        [HttpPut("update/{id}")]
        public async Task<IActionResult> PutBook(int id, [FromBody] Book book)
        {
            if (id != book.Id)
            {
                return BadRequest();
            }

            _context.Entry(book).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }


        //Create a new book
        [HttpPost("add")]
        public async Task<ActionResult<Book>> AddBook(Book book)
        {
            //TO DO
            
            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(SearchByISBN), new { isbn = book.Id }, book);
        }


        //Add a comment on a book
        [HttpPost("isbn/{isbn}/comment/add")]
        public async Task<ActionResult<Book>> AddCommentToBook(Comment comment)
        {
            _context.Comments.Add(comment);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCommentById), new { cid = comment.Id}, comment);
        }
        
        //Delete a book
        [HttpDelete("delete/{isbn}")]
        public async Task<IActionResult> DeleteBook(int isbn)
        {
            var book = await _context.Books.FindAsync(isbn);
            if (book == null)
                return NotFound();
            else
            {
                //delete the book
                _context.Books.Remove(book);
                await _context.SaveChangesAsync();

                //delete the comments that go with the book
                //_context.Comments.RemoveRange(_context.Comments.Where(x => x.BookId == isbn));

                await _context.SaveChangesAsync();
                return NoContent();
            }
            
        }

        //Delete comment by ID
        [HttpDelete("comments/delete/{cid}")]
        public async Task<IActionResult> DeleteCommentById(int cid)
        {
            var comment = await _context.Comments.FindAsync(cid);
            if (comment == null)
                return NotFound();
            else
            {
                _context.Comments.Remove(comment);
                await _context.SaveChangesAsync();
                return NoContent();
            }
        }

        [HttpDelete("isbn/{isbn}/comment/{cid}/delete")]
        public async Task<IActionResult> DeleteBookCommentById(int isbn, int cid)
        {
            var book = await _context.Books.FindAsync(isbn);
            if (book == null)
                return NotFound();
            else
            {
                var comment = await _context.Comments.FindAsync(cid);
                if (comment == null)
                    return NotFound();
                else
                {
                    _context.Comments.Remove(comment);
                    await _context.SaveChangesAsync();
                    return NoContent();
                }
            }
        }
    }
}
