﻿/*
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Library
/// </summary>
/// 
namespace TP3RestBiblioServer.Models
{
    public class Library
    {
        public static List<Book> catalogue;
        public static Dictionary<int, Subscriber> subscriberIndex;
        public static Dictionary<int, Admin> adminIndex;
        public static Dictionary<int, User> connectedUsers;
        public static int id_count;
        //Construtor
        static Library()
        {
            //initialize library
            catalogue = new List<Book>();
            subscriberIndex = new Dictionary<int, Subscriber>();
            connectedUsers = new Dictionary<int, User>();
            adminIndex = new Dictionary<int, Admin>();
            id_count = 1;

            //test

            //1. adding books
            Book b;
            List<Comment> comments;
            comments = new List<Comment>();
            b = new Book(1, "Java for beginners", "Mr xxx", "Mr editor", 100);
            comments.Add(new Comment(1, "Comment #1"));
            comments.Add(new Comment(6, "Comment #2"));
            comments.Add(new Comment(2, "Comment #3"));
            b.CommentList = comments;
            catalogue.Add(b);


            comments = new List<Comment>();
            b = new Book(2, "Harry Potter and the Goblet of Fire", "JK Rowling", "idk", 30);
            comments.Add(new Comment(2, "Good book"));
            comments.Add(new Comment(8, "Nice"));
            comments.Add(new Comment(6, "Boring"));
            b.CommentList = comments;
            catalogue.Add(b);

            comments = new List<Comment>();
            b = new Book(3, "Harry Potter and the Order of the Phoenix", "JK Rowling", "idk", 30);
            comments.Add(new Comment(2, "Fascinating book"));
            comments.Add(new Comment(8, "Saddest book of the series"));
            comments.Add(new Comment(6, "very good book"));
            b.CommentList = comments;
            Library.catalogue.Add(b);

            //2. Adding subscribers
            //Subscriber subscriber = new Subscriber(1, "pass", 25);
            //subscriberIndex.Add(subscriber.id.Value, subscriber);

            addSubscriber("pass", 25);

            //Subscriber subscriber2 = new Subscriber(2, "pass", 21);
            //subscriberIndex.Add(subscriber2.id.Value, subscriber2);
            addSubscriber("pass", 21);

            //3. Adding admins

            //Admin admin = new Admin(3, "pass", "BU Sciences");
            //adminIndex.Add(admin.id.Value, admin);

            addAdmin("pass", "BU Sciences");


            //Admin admin2 = new Admin(4, "pass", "BU Paul Valery");
            //adminIndex.Add(admin2.id.Value, admin2);

            addAdmin("pass", "BU Paul Valery");

            //end of test
        }

        //get all books
        public static List<Book> getAllBooks()
        {
            return catalogue;
        }

        //get all subscribers
        public static List<Subscriber> getAllSubscribers()
        {
            return subscriberIndex.Values.ToList();
        }

        //get all subscribers
        public static List<Admin> getAllAdmins()
        {
            return adminIndex.Values.ToList();
        }
        //search for a book by looking up its isbn
        
        public static Book searchByISBN(int isbn)
        {
            for (int i = 0; i < catalogue.Count; i++)
            {
                if (catalogue[i].ISBN == isbn)
                    return catalogue[i];
            }
            return null;
        }

        //search for a book by using its author's name
        //returns a list of matches
        public static List<Book> searchByAuthor(string author)
        {
            List<Book> result = new List<Book>();
            for (int i = 0; i < catalogue.Count; i++)
            {
                if (catalogue[i].Author == author)
                    result.Add(catalogue[i]);
            }
            return result;
        }

        //login a subscriber using id and password
        //verify that the id and password exist
        //if yes, add user to list of online users
        public static bool loginSubscriber(int id, string password)
        {
            logout(id);
            if (subscriberIndex.ContainsKey(id))
            {
                if (subscriberIndex[id].Password == password)
                {
                    connectedUsers.Add(subscriberIndex[id].Id.Value, subscriberIndex[id]);
                    return true;
                }

            }
            return false;
        }

        //login an admin using an id and a pssword
        //verify that the id and password exist
        //if yes, add user to list of online users
        public static bool loginAdmin(int id, string password)
        {
            logout(id);
            if (adminIndex.ContainsKey(id))
            {
                if (adminIndex[id].Password == password)
                {
                    connectedUsers.Add(adminIndex[id].Id.Value, adminIndex[id]);
                    return true;
                }

            }
            return false;
        }


        //log out using the user id that exists on the user's program
        //remove user from list of online users
        public static void logout(int id)
        {
            connectedUsers.Remove(id);
        }

        //add a comment to a Book
        public static bool addComment(int isbn, int userid, string comment)
        {
            foreach (Book b in catalogue)
            {
                if (b.ISBN == isbn)
                {
                    b.CommentList.Add(new Comment(userid, comment));
                    return true;

                }
            }
            return false;
        }

        //Add a book
        public static bool addBook(int isbn, string title, string author, string editor, int nb)
        {
            Book b = new Book(isbn, title, author, editor, nb);

            for (int i = 0; i < catalogue.Count; i++)
            {
                if (catalogue[i].ISBN == isbn)
                {
                    return false;
                }
            }
            catalogue.Add(b);
            return true;
        }

        //Remove a book by using its isbn
        public static bool removeBook(int isbn)
        {
            for (int i = 0; i < catalogue.Count; i++)
            {
                if (catalogue[i].ISBN == isbn)
                {
                    catalogue.Remove(catalogue[i]);
                    return true;
                }
            }
            return false;
        }

        //Add a subscriber

        public static Subscriber addSubscriber(string password, int age)
        {

            Subscriber s = new Subscriber(id_count, password, age);

            if (!subscriberIndex.ContainsKey(s.Id.Value))
            {
                subscriberIndex.Add(s.Id.Value, s);
                id_count++;
                Console.Write("ADDING A SUBSCRIBVER");
                return s;
            }

            return null;

        }


        //Add an admin
        public static Admin addAdmin(string password, string libraryname)
        {

            Admin s = new Admin(id_count, "pass", libraryname);
            if (!adminIndex.ContainsKey(s.Id.Value))
            {
                adminIndex.Add(s.Id.Value, s);
                id_count++;
                return s;
            }
            return null;
        }
    }
}

*/