﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TP3RestBiblioServer.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TP3RestBiblioServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly BiblioContext _context;

        //Controller's construtor
        public UserController(BiblioContext context)
        {
            _context = context;

            if (_context.Subscribers.Count() == 0)
            {
                //Add a subscriber to test
                Subscriber s1 = new Subscriber("joseph.saba@montpellier.fr", "password", 25, "Joseph");
                _context.Subscribers.Add(s1);

                Subscriber s2 = new Subscriber("dima.moustafa@montpellier.fr", "password", 23, "Hadia");
                _context.Subscribers.Add(s2);

                //persist the changes
                _context.SaveChanges();
            }

            if (_context.Admins.Count() == 0)
            {
                //add admins if there are none
            }
        }

        //test getting all subscribers
        [HttpGet("subscribers")]
        public async Task<ActionResult<List<Subscriber>>> GetAllSubscribers()
        {
            return await _context.Subscribers.ToListAsync();
        }

        //get Subscriber by id
        [HttpGet("subscriber/{id}")]
        public async Task<ActionResult<Subscriber>> GetSubscriberById(int id)
        {
            var userres = await _context.Subscribers.FindAsync(id);
            if (userres == null)
                return NotFound();
            return userres;
        }

        //login
        [HttpPost("subscriber/login")]
        public async Task<ActionResult<Subscriber>> Login(Subscriber sub)
        {
            var subres = await _context.Subscribers.FirstOrDefaultAsync(s => s.Email.Equals(sub.Email) && s.Password.Equals(sub.Password));
            // && s.Password.Equals(password)
            //var subres = _context.Subscribers.Find(1);
            return subres;
        }
        //logout

           
        //sign up
        [HttpPost("subscriber/signup")]
        public async Task<ActionResult<String>> SignUp(Subscriber subscriber)
        {
            //check if email already exists
            var subres = _context.Subscribers.Where(s => s.Email.Equals(subscriber.Email));
            if (subres == null)
            {
                return NotFound();
            }
            else
            {
                await _context.Subscribers.AddAsync(subscriber);
                await _context.SaveChangesAsync();
                return "email";
            }
        }

        
    }
}
