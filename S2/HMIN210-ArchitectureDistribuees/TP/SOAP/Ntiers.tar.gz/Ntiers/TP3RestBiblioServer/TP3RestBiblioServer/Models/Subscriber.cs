﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Subscriber represents the regular user interacting with the system
/// </summary>
/// 

namespace TP3RestBiblioServer.Models
{
    public class Subscriber : User
    {
        public int Age { get; set; }

        public Subscriber() : base()
        {
        }

        public Subscriber(string email, string password, int age, string name) : base(email, password, name)
        {
            this.Age = age;
        }


    }
}