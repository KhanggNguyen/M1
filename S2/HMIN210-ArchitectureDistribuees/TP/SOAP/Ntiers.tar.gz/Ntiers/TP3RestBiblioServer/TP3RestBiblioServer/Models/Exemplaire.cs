﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TP3RestBiblioServer.Models
{
    public class Exemplaire
    {
        
        public int Id { get; set; }
        public string BuyingDate { get; set; }
        public bool Available { get; set; }
        public int ISBNRef { get; set; }

        public Exemplaire()
        {
        }

        public Exemplaire(int id, string buyingDate, bool available, int iSBNRef)
        {
            Id = id;
            BuyingDate = buyingDate;
            Available = available;
            ISBNRef = iSBNRef;
        }
    }
}
