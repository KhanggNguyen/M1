﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

/// <summary>
/// Summary description for Book
/// </summary>
/// 
namespace TP3BiblioClient
{
    public class Book
    {

        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Editor { get; set; }
        public virtual ICollection<Comment> CommentList { get; set; }
        public List<Exemplaire> ExemplairesList { get; set; }

    public Book()
        {

        }

        public Book(int isbn, string title, string author, string editor)
        {
            
            this.Id = isbn;
            this.Title = title;
            this.Author = author;
            this.Editor = editor;
            CommentList = new List<Comment>();
            ExemplairesList = new List<Exemplaire>();
        }

        public Book(int isbn, string title, string author, string editor, int numberOfCopies, List<Comment> comments, List<Exemplaire> exemplaires)        {

            this.Id = isbn;
            this.Title = title;
            this.Author = author;
            this.Editor = editor;
            CommentList = comments;
            ExemplairesList = exemplaires;
        }

        
        public override string ToString()
        {
            string book = "isbn: " + Id + Environment.NewLine + "title: " + Title + Environment.NewLine + "author: " + Author + Environment.NewLine + "editor: " + Editor;
            StringBuilder builder = new StringBuilder();
            builder.Append(book);

            /*
            for (int i = 0; i < CommentList.Count; i++)
                builder.Append(CommentList[i].ToString());
            */
            return builder.ToString();
        }
        
    }
}