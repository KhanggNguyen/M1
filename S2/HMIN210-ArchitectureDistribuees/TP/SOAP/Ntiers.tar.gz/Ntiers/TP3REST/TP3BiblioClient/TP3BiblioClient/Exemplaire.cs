﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TP3BiblioClient
{
    public class Exemplaire
    {
        
        public int Id { get; set; }
        public string BuyingDate { get; set; }
        public bool Available { get; set; }
        public int ISBNRef { get; set; }

        public Exemplaire()
        {
        }

        public Exemplaire(string buyingDate, bool available, int iSBNRef)
        {
            BuyingDate = buyingDate;
            Available = available;
            ISBNRef = iSBNRef;
        }

        public Exemplaire(int Id, string buyingDate, bool available, int iSBNRef)
        {
            BuyingDate = buyingDate;
            Available = available;
            ISBNRef = iSBNRef;
        }

        public override string ToString()
        {
            return "ID: " + Id + Environment.NewLine + "Reference ISBN: " + ISBNRef + Environment.NewLine +  "Date purchares: " + BuyingDate + Environment.NewLine + "Available to rent: " + Available;
        }
    }
}
