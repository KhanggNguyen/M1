using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace TP3BiblioClient
{
    class Program
    {
        static HttpClient client = new HttpClient();

        //Main
        static void Main(string[] args)
        {
            RunAsync().GetAwaiter().GetResult();
            Console.ReadLine();
        }

        static async Task RunAsync()
        {
            // Update port # in the following line.
            client.BaseAddress = new Uri("https://localhost:44313/api/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));

            try
            {
                Console.WriteLine("Getting all books. \nGet Request to: /api/books");
                List<Book> books = await GetAllBooks();
                for (int i = 0; i < books.Count; i++)
                    Console.WriteLine(books[i] + "\n=============");

                Console.WriteLine("\n\n\nGetting a book by ISBN. \n URL: /api/books/1");
                String b = await GetBookById(1);
                Console.WriteLine(b);

                Console.WriteLine("\n\n\nGetting a book that doesn't exist. \n URL: /api/books/1000");
                b = await GetBookById(1000);
                Console.WriteLine(b);

                Console.WriteLine("\n\nSearching for books by author name. \nGet Request to: /books/author=Linus");
                List<Book> booklistauthor = await SearchBooksByAuthor("Linus");
                foreach (Book bres in booklistauthor)
                    Console.WriteLine(bres + "\n=======");
                
                
                Console.WriteLine("\n\nAdding a book. \nPost Request to: /books");
                Book b1 = new Book(978207, "Le petit prince", "Antoine de St Exupery", "Gallimard ");
                String addBookres = await AddBook(b1);
                

                Console.WriteLine("\n\nDeleting the book that we added. \nDelete Request to: /books/978207");
                var deleteBookRes = await DeleteBook(978207);
                Console.WriteLine(deleteBookRes);

                Console.WriteLine("\n\nUpdating a book.\nPut Request to: /books/1");
                Book newbook = new Book(1, "C for dummies", "Linus", "editor");
                string bookupdateres = await UpdateBook(newbook);
                Console.WriteLine("Updated book:\n" + bookupdateres);

                Console.WriteLine("\n\nAdding the same book again. \nPost Request to: /books");
                addBookres = await AddBook(b1);

                Console.WriteLine("\n\nAdding a comment on this book. \nPost Request to: /books/978207/comments");
                String addCommentres = await AddCommentToBook(978207, new Comment(1, "My favorite children's book", 978207));
                Console.WriteLine(addCommentres);

                Console.WriteLine("Getting all comments on a book. \nGet Request to: /api/books/978207/comments");
                List<Comment> comments = await GetCommentsOfBook(978207);
                for (int i = 0; i < comments.Count; i++)
                    Console.WriteLine(comments[i] + "\n=============");

                
                Console.WriteLine("\n\nDeleting the comment that we added. \nDelete Request to: /comments/2");
                var deleteCommentRes = await DeleteComment(2);
                Console.WriteLine(deleteCommentRes);

                Console.WriteLine("\n\nAdding 2 exemplaires to a book. \nPost Request to: /books/1/exemplaires");
                String addExemplaireres = await AddExemplaireToBook(1, new Exemplaire("01/10/2018", true, 1));
                Console.WriteLine(addExemplaireres);
                String addExemplaireres2 = await AddExemplaireToBook(1, new Exemplaire("30/04/2018", false, 1));
                Console.WriteLine(addExemplaireres2);

                Console.WriteLine("Getting all exemplaires of a book.\nGet Request to: /api/books/1/exemplaires");
                List<Exemplaire> exs = await GetExemplairesOfBook(1);
                for (int i = 0; i < exs.Count; i++)
                    Console.WriteLine(exs[i] + "\n=============");

                Console.WriteLine("Getting exemplaire by ID.\nGet Request to: /api/exemplaires/1");
                string exsid = await GetExemplaireById(1);
                Console.WriteLine(exsid);

                Console.WriteLine("Trying to get an exemplaire that doesn't exist.\nGet Request to: /api/exemplaires/100");
                string exsid2 = await GetExemplaireById(100);
                Console.WriteLine(exsid2);

                
                Console.WriteLine("\n\nDeleting an exemplaire that we added. \nDelete Request to: /exemplaires/4");
                var deleteExpRes = await DeleteExemplaire(4);
                Console.WriteLine(deleteExpRes);

                Console.WriteLine("\n\nUpdating an Exemplaire.\nPut Request to: /exemplaire/1");
                Exemplaire exp1 = new Exemplaire(1, "10/1/2018", false, 1);
                string expupdateres = await UpdateExemplaire(exp1);
                Console.WriteLine("Updated Exemplaire:\n" + expupdateres);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        //Get all books
        static async Task<List<Book>> GetAllBooks()
        {
            List<Book> books = null;

            HttpResponseMessage response = await client.GetAsync("books");
            if (response.IsSuccessStatusCode)
            {
                books = await response.Content.ReadAsAsync<List<Book>>();
            }
            return books;

        }

        //Get book by ID
        static async Task<string> GetBookById(int isbn)
        {
            Book b = null;

            HttpResponseMessage response = await client.GetAsync("books/" + isbn);
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return "Cant find this book";

            }
            b = await response.Content.ReadAsAsync<Book>();
            return b.ToString();
        }

        //Search books by author name
        static async Task<List<Book>> SearchBooksByAuthor(string author)
        {
            List<Book> books = null;

            HttpResponseMessage response = await client.GetAsync("books/author=" + author);
            if (response.IsSuccessStatusCode)
            {
                books = await response.Content.ReadAsAsync<List<Book>>();
            }
            return books;

        }

        //Add a book

        static async Task<string> AddBook(Book book)
        {
            HttpResponseMessage response = await client.PostAsJsonAsync(
                "books", book);
            //response.EnsureSuccessStatusCode();
           //return URI of the created resource.
           if((int) response.StatusCode == 400)
                return "This book couldn't be added";
            return "Book added at: " + response.Headers.Location;
        }

        //Delete a book
        static async Task<String> DeleteBook(int isbn)
        {
            HttpResponseMessage response = await client.DeleteAsync("books/" + isbn);
            if ((int)response.StatusCode == 404)
                return "Failed to delete the book";
            return "Book deleted";
        }

        //Modify a book
        static async Task<String> UpdateBook(Book book)
        {
            HttpResponseMessage response = await client.PutAsJsonAsync("books/"+book.Id, book);
            //response.EnsureSuccessStatusCode();

            // Deserialize the updated product from the response body.
            if(response.StatusCode == HttpStatusCode.OK)
                return "Book update sucessful";
            return "Book update Failed";
            
        }

        
        //add a comment to a book
        static async Task<string> AddCommentToBook(int isbn, Comment comment)
        {
            HttpResponseMessage response = await client.PostAsJsonAsync("books/"+isbn+"/comments", comment);
            
            if (response.StatusCode == HttpStatusCode.BadRequest)
                return "This comment couldn't be added";
            return "Comment added at: " + response.Headers.Location;
        }

        //view all comments on a book
        static async Task<List<Comment>> GetCommentsOfBook(int isbn)
        {
            List<Comment> comments = null;

            HttpResponseMessage response = await client.GetAsync("books/"+isbn+"/comments");
            if (response.IsSuccessStatusCode)
            {
                comments = await response.Content.ReadAsAsync<List<Comment>>();
            }
            return comments;

        }

        //Delete a book
        static async Task<String> DeleteComment(int cid)
        {
            HttpResponseMessage response = await client.DeleteAsync("comments/" + cid);
            if (response.StatusCode == HttpStatusCode.NotFound)
                return "Failed to delete the comment";
            return "Comment deleted";
        }

        //add an exemplaire to a book
        static async Task<string> AddExemplaireToBook(int isbn, Exemplaire exp)
        {
            HttpResponseMessage response = await client.PostAsJsonAsync("books/" + isbn + "/exemplaires", exp);

            if (response.StatusCode == HttpStatusCode.BadRequest)
                return "This exemplaire couldn't be added";
            return "Exemplaire added at: " + response.Headers.Location;
        }

        //view all exemplaires of a book
        static async Task<List<Exemplaire>> GetExemplairesOfBook(int isbn)
        {
            List<Exemplaire> exs = null;

            HttpResponseMessage response = await client.GetAsync("books/" + isbn + "/exemplaires");
            if (response.IsSuccessStatusCode)
            {
                exs = await response.Content.ReadAsAsync<List<Exemplaire>>();
            }
            return exs;

        }

        //Get Exemplaire by ID
        static async Task<String> GetExemplaireById(int eid)
        {
            Exemplaire ex = null;

            HttpResponseMessage response = await client.GetAsync("exemplaires/" + eid);
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return "Cant find this exemplaire";
               
            }
            ex = await response.Content.ReadAsAsync<Exemplaire>();
            return ex.ToString();

        }

        //Delete an exemplaire
        static async Task<String> DeleteExemplaire(int id)
        {
            HttpResponseMessage response = await client.DeleteAsync("exemplaires/" + id);
            if ((int)response.StatusCode == 404)
                return "Failed to delete this exemplaire";
            return "Exemplaire deleted";
        }

        //Modify an exemplaire
        static async Task<String> UpdateExemplaire(Exemplaire e)
        {
            HttpResponseMessage response = await client.PutAsJsonAsync("exemplaires/" + e.Id, e);
            
            if (response.StatusCode == HttpStatusCode.OK)
                return "Exemplaire update sucessful";
            return "Exemplaire update Failed";

        }

    }
}
