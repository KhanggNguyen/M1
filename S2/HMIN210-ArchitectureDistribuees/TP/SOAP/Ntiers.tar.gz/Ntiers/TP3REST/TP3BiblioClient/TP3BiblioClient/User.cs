﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Abstract class to represent different kinds of users of this application (subscribers and admins)
/// </summary>
/// 


namespace TP3BiblioClient
{
    public abstract class User
    {
        public int? Id { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }

        public User()
        {

        }

        protected User(string email, string password, string name)
        {
            this.Email = email;
            this.Password = password;
            this.Name = name;
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}