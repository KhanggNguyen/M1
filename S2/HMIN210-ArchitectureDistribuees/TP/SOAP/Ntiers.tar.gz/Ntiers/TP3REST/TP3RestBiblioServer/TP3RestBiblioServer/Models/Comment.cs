﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// A comment is left by a subscriber on a book
/// </summary>
/// 

namespace TP3RestBiblioServer.Models
{
    public class Comment
    {
        public int Id { get; set; }
        public int userId { get; set; }
        public string text { get; set; }
        //public virtual Book Book { get; set; }
        public int BookId { get; set; }
        public Comment()
        {

        }

        public Comment(int Id, int userId, string contenu, int BookId)
        {
            this.Id = Id;
            this.userId = userId;
            this.text = contenu;
            //this.Book = b;
            this.BookId = BookId;
        }
        /*
        public override string ToString()
        {
            return "userid: " + userId + Environment.NewLine + "comment: " + text;
        }
        */
    }
}