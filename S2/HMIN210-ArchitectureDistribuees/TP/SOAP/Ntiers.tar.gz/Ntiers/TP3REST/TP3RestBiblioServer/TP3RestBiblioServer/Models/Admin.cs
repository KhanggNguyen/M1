﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Administrators are the librarians
/// </summary>
/// 

namespace TP3RestBiblioServer.Models
{
    public class Admin : User
    {
        public string Library_name { get; set; }

        public Admin() : base()
        {

        }

        public Admin(string email, string password, string name,  string library_name) : base(email, password, name)
        {
            this.Library_name = library_name;
        }
    }
}