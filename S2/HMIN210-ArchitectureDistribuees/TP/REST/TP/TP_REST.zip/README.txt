//Participant
//NGUYEN Huu Khang
//TRAN Thi Tra My

Pour exécuter, il faut lancer tout d'abord l'application RESTServer. 

Le serveur va démarrer sur le lien comme suivant https://localhost:44355/

Ensuite, on lance l'application Client. L'application dispose les données codés en dur sur côté serveur. Les instructions sont écrits sur le terminal. 

Pour tous les erreurs de frappe, veuillez redémarrer le côté serveur et le côté client pour éviter les données soient dupliqués. 
