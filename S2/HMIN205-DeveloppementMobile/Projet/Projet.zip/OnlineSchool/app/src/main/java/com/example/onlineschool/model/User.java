package com.example.onlineschool.model;

import org.json.JSONArray;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class User implements Serializable {

    private String Name;
    private String Username;
    private int Age;
    private String Password;
    private String Email;
    private String Address;
    private int Role;
    private int isActive;

    public User(String name, String username, int age, String password, String email, String address, int role) {
        Name = name;
        Username = username;
        Age = age;
        Password = password;
        Email = email;
        Address = address;
        Role = role;
        this.isActive = 0;
    }

    public String getName(){
        return Name;
    }

    public void setName(String n){
        this.Name = n;
    }

    public String getUsername(){
        return Username;
    }

    public void setUsername(String un){
        this.Username = un;
    }

    public int getAge(){
        return Age;
    }

    public void setAge(int a){
        this.Age = a;
    }

    public String getPassword(){
        return Password;
    }

    public void setPassword(String p){
        this.Password = p;
    }

    public String getEmail(){
        return Email;
    }

    public void setEmail(String e){
        this.Email = e;
    }

    public String getAddress(){
        return Address;
    }

    public void setAddress(String a){
        this.Address = a;
    }

    public int getRole() {
        return Role;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setRole(int role) {
        Role = role;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public JSONArray convertToJSONArray(){
        List list = new ArrayList();
        list.add(Name);
        list.add(Username);
        list.add(Age);
        list.add(Password);
        list.add(Email);
        list.add(Address);
        list.add(Role);
        return new JSONArray(list);
    }
}
