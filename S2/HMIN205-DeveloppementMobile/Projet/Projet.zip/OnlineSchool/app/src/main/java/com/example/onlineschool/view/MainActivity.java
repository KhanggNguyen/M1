package com.example.onlineschool.view;

public class MainActivity {


}
