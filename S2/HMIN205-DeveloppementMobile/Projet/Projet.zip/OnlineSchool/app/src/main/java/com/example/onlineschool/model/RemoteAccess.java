package com.example.onlineschool.model;

import android.util.Log;

import com.example.onlineschool.tools.AccessHTTP;
import com.example.onlineschool.tools.AsyncResponse;

import org.json.JSONArray;

public class RemoteAccess implements AsyncResponse {

    //constant
    private static final String SERVERADDR = "http://192.168.0.17/OnlineSchool/index.php";

    /**
     * Constructor
     */
    public RemoteAccess(){
        super();
    }

    /**
     * return from remote server
     * @param output
     */
    @Override
    public void processFinish(String output) {
        Log.d("Serveur : ", output);
    }

    public void send(String operation, JSONArray JSONdata){
        AccessHTTP dataAccess = new AccessHTTP();
        //Delegation link
        dataAccess.delegate = this;
        dataAccess.addParams("operation", operation);
        dataAccess.addParams("lesdonnees", JSONdata.toString());
        //access to server
        dataAccess.execute(SERVERADDR);
    }
}
