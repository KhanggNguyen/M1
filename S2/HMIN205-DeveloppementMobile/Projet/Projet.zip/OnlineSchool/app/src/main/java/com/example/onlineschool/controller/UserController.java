package com.example.onlineschool.controller;

import android.content.Context;
import android.util.Log;

import com.example.onlineschool.model.RemoteAccess;
import com.example.onlineschool.tools.Serializer;
import com.example.onlineschool.view.LoginActivity;
import com.example.onlineschool.view.MainActivity;
import com.example.onlineschool.model.User;
import com.example.onlineschool.view.RegisterActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

public class UserController {
    private static UserController instance = null;
    private static User model;
    private static final String FileName = "savedProfile";
    private static RemoteAccess remoteAccess;

    private MainActivity view;
    private RegisterActivity registerView;
    private LoginActivity loginView;


    private UserController(){
        super();
    }

    /**
     * Return a new object of userController with params
     * @param view
     * @param registerView
     * @param loginView
     * @param model
     */
    public UserController(MainActivity view, RegisterActivity registerView, LoginActivity loginView, User model){
        super();
        this.view = view;
        this.registerView = registerView;
        this.loginView = loginView;
        this.model = model;
    }

    /**
     * Create instance
     * @return instance
     */
    public static final UserController getInstance(Context context) {
        if (UserController.instance == null){
            UserController.instance = new UserController();
            remoteAccess = new RemoteAccess();
            //remoteAccess.send("last", new JSONArray());
            //getSerialize(context);
        }
        return UserController.instance;
    }

    /**
     * Create a new User
     * @param name
     * @param username
     * @param age
     * @param password
     * @param email
     * @param address
     * @param role
     */
    public void CreateUser(String name, String username, int age, String password, String email, String address, int role, Context context){
        model = new User(name, username, age, password, email, address, role);
        //Serializer.serialize(FileName, model, context);
        remoteAccess.send("register", model.convertToJSONArray());
    }

    public void UserLogin(String username, String password, Context context){
        JSONObject jo = new JSONObject();
        try {
            jo.put("username", username);
            jo.put("password", password);
        } catch (JSONException e) {
            Log.d("UserLogin Erreur : ", e.toString());
        }
        JSONArray ja = new JSONArray();
        ja.put(jo);
        remoteAccess.send("login", ja);
    }

    /**
     * Return user infos
     * @return String
     */
    public String getMessage(){
        return model.toString();
    }

    /**
     * Serialize user object
     * @param context
     */
    private static void getSerialize(Context context){
        model = (User) Serializer.unSerialize(FileName, context);
    }
}
