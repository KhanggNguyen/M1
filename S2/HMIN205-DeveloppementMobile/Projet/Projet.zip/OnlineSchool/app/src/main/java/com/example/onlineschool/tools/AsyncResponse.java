package com.example.onlineschool.tools;

public interface AsyncResponse {
    void processFinish(String output);

}
