package com.example.onlineschool.view;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.onlineschool.R;
import com.example.onlineschool.controller.UserController;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class UserAreaActivity extends AppCompatActivity {
    //private UserController userController;
    private FirebaseAuth fAuth;
    private FirebaseFirestore fStore;
    private String userID;


    private EditText etName;
    private EditText etUsername;
    private EditText etAge;
    private EditText etPassword;
    private EditText etAddress;
    private EditText etEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_area);

        init();

        logOut();

    }

    private void init(){
        etAge = (EditText) findViewById(R.id.etAge);
        //etName = (EditText) findViewById(R.id.etName);
        etUsername = (EditText) findViewById(R.id.etUsername);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etAddress = (EditText) findViewById((R.id.etAddress));
        etEmail = (EditText) findViewById(R.id.etEmail);

        //userController = UserController.getInstance(this);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        userID = fAuth.getCurrentUser().getUid();

        final DocumentReference documentReference = fStore.collection("users").document(userID);
        documentReference.addSnapshotListener(UserAreaActivity.this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {
                etAge.setText(documentSnapshot.getString("age"));
                //etName.setText(documentSnapshot.getString("name"));
                etUsername.setText(documentSnapshot.getString("username"));
                etAddress.setText(documentSnapshot.getString("address"));
                etEmail.setText(documentSnapshot.getString("email"));

            }
        });
    }

    private void logOut(){
        ((Button) findViewById(R.id.bLogout)).setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                finish();
            }
        });
    }
}
