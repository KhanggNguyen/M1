package com.example.onlineschool.Models;

public class Prof {


}
