package com.example.tpex1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListeContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_contact);
    }
}
