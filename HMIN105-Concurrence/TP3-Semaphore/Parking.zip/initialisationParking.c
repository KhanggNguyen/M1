#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <fcntl.h>// Pour open(), O_CREAT O_WRONLY
#include <stdio.h> //Pour printf()
#include <sys/shm.h> // Pour shmget(), shmat(), shmdt(), shmctl()
#include <errno.h> // Pour errno
#include <unistd.h> // Pour close(fd)
#include <stdlib.h> // Pour exit(), NULL

union semun{
  int val ;/* cmd = SETVAL */
  struct semidds *buf ;/* cmd = IPCSTAT ou IPCSET */
  unsigned short *array ;    /* cmd = GETALL ou SETALL */
  struct seminfo *__buf ;/* cmd = IPCINFO (sous Linux) */
};

void initialisationParking(char* chemin, int nbPlaces) {
  
  //Création du fichier s'il n'existe pas
  int fd = open(chemin, O_CREAT|O_WRONLY, 0644);
  close(fd);
  
  key_t sesame = ftok(chemin, 2);

  // Création d'une sémaphore associée a la clée cleSem 
  int idSem = semget(sesame, 1, IPC_CREAT|0666);
  
  // Initialisation de la sémaphore a 1
  union semun egCtrl;
  egCtrl.val=1;

  if(semctl(idSem, 0, SETVAL, egCtrl) == -1){
    perror("probl`eme init");//suite
  }

  printf("Creation du segment de mémoire partagée...\n");

  int sh_id = shmget(sesame, sizeof(int), IPC_CREAT|0666);
  if(sh_id<0) {
    exit(0);
  }



  printf("Attachement du segment partagé et récupération de son adresse...\n");
  
  int *shmadr = (int*) shmat(sh_id, NULL, 0);
  if(*shmadr == -1) {
    exit(0);
  }
  
  *shmadr = nbPlaces;

  printf("parking: places=%d.\n" , *shmadr);

  printf("Détachement du segment partagé...\n");
  int error = shmdt((void*)shmadr);

  if(error<0){
    exit(0);
  }

  printf("Fin de l'initialisation.\n");
}

int main(int argc, char **argv) {
  
  if(argc != 3) {
    printf("Utilisation : ./initParking <chemin> <nbPlacesParking>");
    exit(0);
  }

  int nbPlaces = atoi(argv[2]);
  initialisationParking(argv[1], nbPlaces);
  
  

  return 0;
}
