#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <fcntl.h>// Pour open(), O_CREAT O_WRONLY
#include <stdio.h> //Pour printf()
#include <sys/shm.h> // Pour shmget(), shmat(), shmdt(), shmctl()
#include <errno.h> // Pour errno
#include <unistd.h> // Pour close(fd)
#include <stdlib.h> // Pour exit(), NULL

struct sembuf op[] = {
    { 0, -1, SEM_UNDO }, //lock
    { 0, 1, SEM_UNDO } //unlock
};  


int main() {

    int fd = open("test", O_CREAT|O_WRONLY, 0644);
    close(fd);
    
    key_t sesame = ftok("test", 2);

    printf("Creation du segment de mémoire partagée...\n");

    int sh_id = shmget(sesame, 0, 0666);
    if(sh_id<0) {
        exit(0);
    }
    // Création d'une sémaphore associée a la clée cleSem 
    int idSem = semget(sesame, 1, 0666);

    printf("Attachement du segment partagé et récupération de son adresse...\n");
        int *nbPlacesDispo = (int*) shmat(sh_id, NULL, 0);
        if(*nbPlacesDispo == -1) {
         exit(0);
        }

    while (1) {


        int error = semop(idSem, op, 1); // Vérouillage du segment partagée
        if(error == -1) {
         exit(0);
        }  

        if (*nbPlacesDispo > 0) {
            printf("Demande accepté\n");
            (*nbPlacesDispo)++;
            printf("Impression ticket\n");
            printf("Nombre de place restante : %d\n", (*nbPlacesDispo));
        } else {
            printf("Pas de place\n");
        }

        error = semop(idSem, op+1, 1); // Déverouillage du segment partagée
        if(error == -1) {
         exit(0);
        }

        sleep(2);

    }


  return 0;
}
